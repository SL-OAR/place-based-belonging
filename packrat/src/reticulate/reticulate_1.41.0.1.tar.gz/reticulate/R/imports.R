
#' @importFrom utils capture.output download.file tail
#' @importFrom png readPNG writePNG
#' @importFrom jsonlite fromJSON
NULL
