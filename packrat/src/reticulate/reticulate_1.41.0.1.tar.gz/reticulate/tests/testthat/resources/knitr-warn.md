    import warnings
    warnings.warn("a warning")
    1 + 1

    ## 2

    ## 2
