/* modulo  */
double mod(double x, double n) ;

/* Convert degrees to radians */
double toRad(double deg) ; 

/* Convert radians to degrees */
double toDeg(double rad) ; 

/* normatlize longitude between -180 .. 180 degrees*/
double normalizeLonDeg(double lon);

/* normatlize longitude between -pi .. p1 radians*/
double normalizeLonRad(double lon);

