# snapshot

    Code
      11:20
    Output
       [1] 11 12 13 14 15 16 17 18 19 20

