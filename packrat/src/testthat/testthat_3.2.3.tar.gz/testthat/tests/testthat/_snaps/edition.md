# deprecation only fired for newer edition

    Code
      edition_deprecate(3, "old stuff")
    Condition
      Warning:
      `old stuff` was deprecated in the 3rd edition.

