# reporter as expected

    Start test: Success
      'reporters/tests.R:6:3' [success]
    End test: Success
    
    Start test: Failure:1
      'reporters/tests.R:12:3' [failure]
    End test: Failure:1
    
    Start test: Failure:2a
      'reporters/tests.R:16:8' [failure]
    End test: Failure:2a
    
    Start test: Error:1
      'reporters/tests.R:23:3' [error]
    End test: Error:1
    
    Start test: errors get tracebacks
      'reporters/tests.R:29:8' [error]
    End test: errors get tracebacks
    
    Start test: explicit skips are reported
      'reporters/tests.R:37:3' [skip]
    End test: explicit skips are reported
    
    Start test: empty tests are implicitly skipped
      'reporters/tests.R:40:1' [skip]
    End test: empty tests are implicitly skipped
    
    Start test: warnings get backtraces
      'reporters/tests.R:47:5' [warning]
      'reporters/tests.R:45:1' [skip]
    End test: warnings get backtraces
    

