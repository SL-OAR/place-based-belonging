# generates useful failure messages

    invisible(1) returns invisibly, not visibly.

---

    1 returns visibly, not invisibly.

