# deprecated

    Code
      local_mock()
    Condition
      Warning:
      `local_mock()` was deprecated in testthat 3.3.0.
      i Please use `local_mocked_bindings()` instead.

---

    Code
      with_mock(is_testing = function() FALSE)
    Condition
      Warning:
      `with_mock()` was deprecated in testthat 3.3.0.
      i Please use `with_mocked_bindings()` instead.

