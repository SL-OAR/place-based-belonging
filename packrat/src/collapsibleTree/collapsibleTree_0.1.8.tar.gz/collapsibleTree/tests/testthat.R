library(testthat)
library(collapsibleTree)

test_check("collapsibleTree")
