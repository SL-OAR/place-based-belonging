#'@keywords internal
react_version <- function(){'18.2.0'}
babel_version <- function(){'6.26.0'}