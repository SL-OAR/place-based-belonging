# can't can't compare large integers

    Code
      num_equal(9007199254740996, bit64::as.integer64(1))
    Condition
      Error in `num_equal()`:
      ! No way to coerce to compatible numeric type.
      i Try again without setting `tolerance`.

