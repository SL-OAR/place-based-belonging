library(testthat)
library(ggfittext)

test_check("ggfittext")
