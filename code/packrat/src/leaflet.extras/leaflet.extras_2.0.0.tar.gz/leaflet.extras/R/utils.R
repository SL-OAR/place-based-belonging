iconSetToIcons <- utils::getFromNamespace("iconSetToIcons", "leaflet")
b64EncodePackedIcons <- utils::getFromNamespace("b64EncodePackedIcons", "leaflet")
packStrings <- utils::getFromNamespace("packStrings", "leaflet")
awesomeIconSetToAwesomeIcons <- utils::getFromNamespace("awesomeIconSetToAwesomeIcons", "leaflet")


# getCrosstalkOptions <- function (data) {
#   if (is.SharedData(data)) {
#     list(ctKey = data$key(), ctGroup = data$groupName())
#   }
#   else {
#     NULL
#   }
# }
